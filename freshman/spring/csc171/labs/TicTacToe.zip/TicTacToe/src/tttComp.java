
public class tttComp {

	public void max(int[][] table, int depth){
		
	}
	
	//Check first row
	
}
