A = 1;
f = 220;
phi = pi/3;
x = Acos(2*pi*f*t + phi);
R = 44100;
soundsc(x,R)

