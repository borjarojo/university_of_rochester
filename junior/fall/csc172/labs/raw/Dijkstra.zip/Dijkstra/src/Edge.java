/*
 * Borja Rojo
 * CSC 172
 * Partner: Daniel Saltz
 */
public class Edge {
	public final int v, w;
	public int weight;
	
	public Edge(int v, int w, int weight){
		this.v = v;
		this.w = w;
		this.weight = weight;
	}
}
