/*
 * Borja Rojo
 * CSC 172
 * Partner: Daniel Saltz
 */
public interface AdjList {
	int begin();
	int next();
	boolean end();
}
