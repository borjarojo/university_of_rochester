/*
 * Borja Rojo
 * CSC 172
 * Partner: Daniel Saltz
 */
public class Edge {
	public final int v, w;
	
	public Edge(int v, int w){
		this.v = v;
		this.w = w;
	}
}
