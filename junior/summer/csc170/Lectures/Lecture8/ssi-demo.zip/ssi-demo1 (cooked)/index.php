<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>SSI Demo</title>
</head>
<body>

<div>Just some regular HTML here</div>

<?php include "inc/more-content.inc"; ?>

<div>And then some more regular HTML, whatever</div>

</body>
</html>