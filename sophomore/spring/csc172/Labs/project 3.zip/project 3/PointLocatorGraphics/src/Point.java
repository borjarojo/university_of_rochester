/*
 * Borja Rojo
 * project3
 * 4/11/15
 */

public class Point {
	public double x;
	public double y;

	//constructor that sets the x and y values of the point to the parameters
	public Point(double a, double b)
	{
		x = a;
		y = b;
	}
}
