#!/bin/bash
gcc lab8main.c
gcc -o lab8main lab8main.c
chmod 777 lab8main
./lab8main
