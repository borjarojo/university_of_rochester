/*
 Borja Rojo
 4/19/15
 Lab Partner: Daniel Saltz
 
 */

public class Vertex {
	public boolean known;
	public int distance;
	public Vertex path;
	public String data;
}
