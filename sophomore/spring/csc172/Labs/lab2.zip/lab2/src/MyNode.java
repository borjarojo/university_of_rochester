/*
 * Borja Rojo
 * 
 * Due February 1, 2015
 * 
 * CSC 172
 * 
 * Lab 3
 */
public class MyNode<AnyType> {
	public AnyType data;
	public MyNode<AnyType> next;
}
