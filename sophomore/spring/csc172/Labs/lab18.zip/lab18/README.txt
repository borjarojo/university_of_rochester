Borja Rojo
CSC172
4/12/15
Daniel Saltz

Graphs

Java Files: MainTest.java, Graphs.java
Classes inside Graphs.java: private Edge class, private AdjArray class, 
private Vertex class, and an AdjList interface.

Run Steps: You can put this file into eclipse and run it. 
Make sure to enter the correct file paths when asked. If
you run this in eclipse, use the name of the file. If you
decide to run this in the command line, make sure you
type the correct file path.

The goal of this lab is to create graphs. I created an unweighted shortest path algorithm, 
and tested it with examples 9.10 and 9.62 from the textbook. I created those files, 
and used them to test my program. I also created two other test graphs. I printed all 
4 of the graphs out to the console, as shown in my OUTPUT file.

