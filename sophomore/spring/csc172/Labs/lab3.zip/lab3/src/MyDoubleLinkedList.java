/*
 * Borja Rojo
 * 
 * Due February 1, 2015
 * 
 * CSC 172
 * 
 * Lab 3
 * 
 * Lab Partner : Daniel Saltz
 */

//part2 of lab3
public interface MyDoubleLinkedList {
	public void insert(Object x);
	public void delete(Object x);
	public boolean lookup(Object x);
	public boolean isEmpty();
	public void printList();
	public void printListRev();
}