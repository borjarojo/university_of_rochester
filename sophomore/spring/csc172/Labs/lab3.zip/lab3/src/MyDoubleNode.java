/*
 * Borja Rojo
 * 
 * Due February 1, 2015
 * 
 * CSC 172
 * 
 * Lab 3
 * 
 * Lab Partner : Daniel Saltz
 */

//part1 of lab3
public class MyDoubleNode {
	public Object data;
	public MyDoubleNode next;
	public MyDoubleNode prev;
}