
public class DoubleNode<AnyType> {
	public AnyType data;
	public DoubleNode<AnyType> next;
	public DoubleNode<AnyType> prev;
	
	public DoubleNode(){
		
	}
	
	public DoubleNode(AnyType x){
		data = x;
	}
}
